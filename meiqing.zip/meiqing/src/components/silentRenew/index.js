import {processSilentRenew} from 'redux-oidc';
console.log('silent renew');
processSilentRenew();
