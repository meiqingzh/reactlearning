import * as React from 'react';
import * as ExampleCounterStore from '../../redux/reducers/initialState';
import * as ExampleCounterActions from '../../redux/actions/exampleCounterActions';
import { AppState } from '../../redux/reducers';
import { connect } from 'react-redux';
import callApi from '../../api/WebApi'

import { Button} from "@blueprintjs/core";

interface DispatchProps {
  increment: () => void;
  decrement: () => void;
}

type CounterProps = ExampleCounterStore.CounterState & DispatchProps;

const Counter = (props: CounterProps) => {

const [apiResult, setApiResult] = React.useState('');


  return (
    <div className="container">
      <h2>Counter and Web Api</h2>
          <p> counter store state in redux. Current count: <strong>{props.count}</strong></p>
          <p></p>
          <p>Call WebApi result: {apiResult ?  apiResult: "please call wep api" }</p>
          <Button icon="add"       
        onClick={() => {
          props.increment();
        }}>
        Increment
      </Button>
          
          <Button
              icon="minus"
        onClick={() => {
          props.decrement();
        }}>
        Decrement
      </Button>
          
          <Button  
              icon="pin"
              onClick={() => {                 
                      callApi(setApiResult);
                  }}>
                  Call  web api
      </Button>
         
          <Button
              icon="clean"
              onClick={() => {
                  setApiResult("");
              }}>
              clear web api call result
      </Button>
          
    </div>
  );
};

export default connect(
  // Selects which state properties are merged into the component's props
  (state: AppState): ExampleCounterStore.CounterState => state.counter,
  // Selects which action creators are merged into the component's props
    ExampleCounterActions.actionCreators
)(Counter);
