﻿import * as moment from 'moment';
import 'moment/locale/zh-cn';

export function GetChineseDisplay(utcTime) {
    moment.locale("zh-cn");
    return moment.utc(utcTime).format("YY年M月D");    
}