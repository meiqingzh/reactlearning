import * as React from 'react';
import userManager from '../api/userManager';
import { Link } from 'react-router-dom';
import { Button, Navbar, Divider } from "@blueprintjs/core";


interface NavProps {
    isConnected: boolean;
    path: string;
}

const Nav = (props: NavProps) => {
    const logout = (event: any) => {
        event.preventDefault();
        userManager.signoutRedirect();
        userManager.removeUser();
    };

    const login = () => {
        // pass the current path to redirect to the correct page after successfull login
        debugger;
        userManager.signinRedirect({
            data: { path: props.path },
        });
        debugger;
    };

    return (
        <Navbar>
            <Navbar.Group align="left">
                <Link to="/" className="pt-navbar">
                    Home
        </Link>
                <Divider />
                <Link to="/DevexpressGridExample" className="pt-navbar">
                    Grid
        </Link>
                <Divider />
                <Link to="/DevexpressGridWithRedux" className="btn btn-link">
                    GridRedux
        </Link>
                <Divider />
                <Link to="/counter" className="btn btn-link">
                    Counter & Web API
        </Link>
                <Divider />
                
                <Link to="/user" className="btn btn-link">
                    User tokens from identityServer
        </Link>
            </Navbar.Group>
            <Navbar.Group align="right">
                {props.isConnected ? (
                    <Button intent="primary"  onClick={(event: any)=> logout(event)}>
                        Logout
          </Button>
                ) : (
                        <Button intent= "primary"  onClick={() => login()}>
                            Login
          </Button>
                    )}
            </Navbar.Group>
            </Navbar>
    );
};

export default Nav;
