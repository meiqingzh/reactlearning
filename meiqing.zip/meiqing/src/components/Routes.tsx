import Counter from './Examples/Counter';
import DevexpressGridExample from './Examples/Devexpressgrid';
import DevexpressGridWithRedux from './Examples/DevexpressGridWithRedux'
import * as React from 'react';
import {connect} from 'react-redux';
import {Route, Switch} from 'react-router-dom';
import CallbackPage from './user/CallbackPage';
import {AppState} from '../redux/reducers';
import userManager from '../api/userManager';
import {User} from 'oidc-client';
import axios from 'axios';
import UserInfo from './user/UserInfo';
import {Dispatch} from 'redux';
import Nav from './Nav';
import AboutPage from './about/AboutPage';

interface RoutesModuleProps {
  user: User;
  isLoadingUser: boolean;
  dispatch: Dispatch;
  location: any;
}

const Routes = (props: RoutesModuleProps) => {
  console.log(props);

  // wait for user to be loaded, and location is known
  if (props.isLoadingUser || !props.location) {
    return <div>Loading...</div>;
  }

  // if location is callback page, return only CallbackPage route to allow signin process
  // IdentityServer 'bug' with hash history: if callback page contains a '#' params are appended with no delimiter
  // eg. /callbacktoken_id=...
  const url = props.location.pathname.substring(0, 9);
  if (url === '/callback') {
    const rest = props.location.pathname.substring(9);
    return <CallbackPage {...props} signInParams={`${url}#${rest}`} />;
  }

  // check if user is signed in
  userManager.getUser().then(user => {
    if (user && !user.expired) {
      // Set the authorization header for axios
      axios.defaults.headers.common['Authorization'] = 'Bearer ' + user.access_token;
    }
  });

  const isConnected: boolean = !!props.user;

  return (
    <React.Fragment>
      <Nav isConnected={isConnected} path={props.location.pathname} />
      <Switch>
              <Route exact path="/" component={AboutPage} />
              <Route path="/DevexpressGridExample" component={DevexpressGridExample} />
              <Route path="/counter" component={Counter} />
              <Route path="/DevexpressGridWithRedux" component={DevexpressGridWithRedux} />
        <Route path="/user" component={UserInfo} />       
      </Switch>
    </React.Fragment>
  );
};

function mapStateToProps(state: AppState) {
  return {
    user: state.oidc.user,
    isLoadingUser: state.oidc.isLoadingUser,
    location: state.router.location,
  };
}

function mapDispatchToProps(dispatch: Dispatch) {
  return {
    dispatch,
  };
}

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Routes);
