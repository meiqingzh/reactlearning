import React from "react";
import PropTypes from 'prop-types';
import Typography from '@material-ui/core/Typography';
import { withStyles } from '@material-ui/core/styles';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';

const styles = theme => ({
    root: {
        width: '100%',
        maxWidth: 360,
        backgroundColor: theme.palette.background.paper,
    },
    inline: {
        display: 'inline',
    },
});

const AboutPage = (props) => {
    const { classes } = props;
    return (
        <div>
            <h2></h2>
            <Typography variant="h2" gutterBottom>
                Thank you for looking at my learning project
      </Typography>
           
            <Typography variant="h4" gutterBottom>
                Let me explain a little bit before you click links. 
      </Typography>

            <List className={classes.root}>
                <ListItem alignItems="flex-start">

                    <ListItemText
                        primary="Grid?"
                        secondary={
                            <React.Fragment>
                                <Typography component="span" className={classes.inline} color="textPrimary">
                                    It is a basic table. no action.
              </Typography>
                                {" boring "}
                            </React.Fragment>
                        }
                    />
                </ListItem>

                <ListItem alignItems="flex-start">
                <ListItemText
                    primary="GridRedux?"
                    secondary={
                        <React.Fragment>
                            <Typography component="span" className={classes.inline} color="textPrimary">
                                It is a master-detail table. many actions. 
              </Typography>
                            {" interesting? "}
                        </React.Fragment>
                    }
                />
                </ListItem>
                <ListItem alignItems="flex-start">
                    <ListItemText
                        primary="Counter & Web Api?"
                        secondary={
                            <React.Fragment>
                                <Typography component="span" className={classes.inline} color="textPrimary">
                                    It is a simple page with 4 buttons. Calling Web Api. interact with Redux store for state management.
              </Typography>
                                {" "}
                            </React.Fragment>
                        }
                    />
                </ListItem>
           
                <ListItem alignItems="flex-start">
                    
                    <ListItemText
                        primary="login?"
                        secondary={
                            <React.Fragment>
                                <Typography component="span" className={classes.inline} color="textPrimary">
                                   It will not work unless you have an Identity Server 4 to accept user login.
              </Typography>
                                {" "}
                            </React.Fragment>
                        }
                    />
                </ListItem>
                <ListItem alignItems="flex-start">
                   
                    <ListItemText
                        primary="oidc-client configuration?"
                        secondary={
                            <React.Fragment>
                                <Typography component="span" className={classes.inline} color="textPrimary">
                                   it is in the folder src/api/userManager.ts
              </Typography>
                                {" "}
                            </React.Fragment>
                        }
                    />
                </ListItem>
                <ListItem alignItems="flex-start">
                    
                    <ListItemText
                        primary="Web Api Call?"
                        secondary={
                            <React.Fragment>
                                <Typography component="span" className={classes.inline} color="textPrimary">
                                    I commented out real one for UI display for you to view.
              </Typography>
                                {'The source code is in src/api/webapi.js '}
                            </React.Fragment>
                        }
                    />
                </ListItem>
            </List>

          

            <Typography variant="h2" gutterBottom>
                Thank you
      </Typography>
        </div>
    );
}

AboutPage.propTypes = {
    classes: PropTypes.object.isRequired,
};

export default withStyles(styles)(AboutPage);


