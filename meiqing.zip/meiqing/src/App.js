"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var React = require("react");
var Routes_1 = require("./components/Routes");
var react_redux_1 = require("react-redux");
var configureStore_1 = require("./redux/configureStore");
var connected_react_router_1 = require("connected-react-router");
var history_1 = require("history");
require("./App.css");
var history = history_1.createHashHistory();
var store = configureStore_1.default(history);
var App = function () { return (React.createElement(react_redux_1.Provider, { store: store },
    React.createElement(connected_react_router_1.ConnectedRouter, { history: history },
        React.createElement(Routes_1.default, null)))); };
exports.default = App;
//# sourceMappingURL=App.js.map