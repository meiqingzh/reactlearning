// STATE - This defines the type of data maintained in the Redux store.
export interface CounterState {
    count: number;
    isLoading: boolean;
}

export const initialCounterState: CounterState = {
    count: 0,
    isLoading: false,
};

export const initialState =  {
    apiCallsInProgress: 0,
    CounterState: initialCounterState
}