﻿import axios from 'axios';
//const callApi = (setApiResult:Function) => {
//    // quick and dirty test for calling the api
//    axios
//        .get('http://localhost/Test.Web.Api/api/v1.0/ping')
//        .then((response: any) => {
//            debugger;
//            console.log(response);
//            setApiResult(JSON.stringify(response.data, null, 2));
//        })
//        .catch(error => {           
//            const { status, statusText } = error.response;
//            setApiResult(`${status}: ${statusText}`);            
//        });
//};

const callApi = (setApiResult: Function) => {
    setApiResult("Called API. Real one need web api support at server.")
}
export default callApi;