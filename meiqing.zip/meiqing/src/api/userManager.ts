import { createUserManager } from 'redux-oidc';
import { UserManagerSettings } from 'oidc-client';

//const userManagerConfig: UserManagerSettings = {
//    client_id: 'coyote_client',
//  redirect_uri: 'http://localhost:5100/#/callback',
//  response_type: 'token id_token',
//  scope:"openid profile",
//    authority: 'http://localhost:59354/',
//  silent_redirect_uri: 'http://localhost:5100/silentRenew.html',
//  automaticSilentRenew: true,
//  filterProtocolClaims: true,
//  loadUserInfo: true,
//  monitorSession: true
//};

const userManagerConfig: UserManagerSettings = {
    client_id: 'spa',
    redirect_uri: 'http://localhost:3000/#/callback',
    response_type: 'token id_token',
    scope: "openid profile api1",
    authority: 'http://localhost:5000',
    silent_redirect_uri: 'http://localhost:3000/silentRenew.html',
    automaticSilentRenew: true,
    filterProtocolClaims: true,
    loadUserInfo: true,
    monitorSession: true
};


const userManager = createUserManager(userManagerConfig);

export default userManager;